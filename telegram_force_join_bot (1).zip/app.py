from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# اطلاعات ربات و کانال
TOKEN = "8437778241:AAGDCdKLvzv5bq_nOq8kJgiuG0bCyUZz1fs"
CHANNEL = "@nilo_1313"
YOUTUBE = "https://www.youtube.com/@drYouTube18"
VIDEO = "BAACAgQAAxkBAAECuopouWVUJtfMpcsmetdNqNPVz9REhQAC5gsAAjv7cFGU6qYqULI0MjYE"  # File ID ویدیو

# شروع
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📢 عضویت در کانال", url=f"https://t.me/{CHANNEL[1:]}")],
        [InlineKeyboardButton("🎥 سابسکرایب یوتیوب", url=YOUTUBE)],
        [InlineKeyboardButton("✅ تایید کردم", callback_data="check")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "سلام 👋\n"
        "برای دریافت ویدیو:\n"
        "1️⃣ عضو کانال شو\n"
        "2️⃣ تو یوتیوب سابسکرایب کن\n"
        "بعد روی ✅ بزن 👇",
        reply_markup=reply_markup
    )

# چک کردن
async def check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    member = await context.bot.get_chat_member(CHANNEL, user_id)

    if member.status in ["member", "administrator", "creator"]:
        await query.message.reply_text("✅ عالی! اینم ویدیوی شما 🎬")
        await query.message.reply_video(
            VIDEO,
            protect_content=True   # جلو فوروارد و ذخیره‌سازی گرفته میشه
        )
    else:
        await query.message.reply_text(
            "❌ هنوز عضو کانال نیستی.\n"
            f"لطفاً عضو {CHANNEL} شو و دوباره تایید کن."
        )

# اجرای ربات
app = Application.builder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(check, pattern="check"))
app.run_polling()
